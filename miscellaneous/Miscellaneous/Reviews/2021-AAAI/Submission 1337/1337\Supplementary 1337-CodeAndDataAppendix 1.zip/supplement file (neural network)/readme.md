Explanation for supplement file
1. Appendix
This is appendix file for the paper. It includes the structure of neural networks, the basic formula of neural networks and the arrangement result for manpower scheduling problems.

2. demo_code
This is an ipynb file containing the implement for different neural networks described in the paper.

3. drawing_code
This is an ipynb file for providing the visualization result.