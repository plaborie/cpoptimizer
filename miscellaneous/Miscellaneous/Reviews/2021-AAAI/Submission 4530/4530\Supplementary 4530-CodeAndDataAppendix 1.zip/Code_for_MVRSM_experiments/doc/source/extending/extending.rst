Extending
=========

Guides to how to add your own approaches and problems are listed below.

.. toctree::
    dependency_management
    adding_approaches
    adding_problems