loc=$(dirname "$0")
cp $loc/dockerCall.py .
cp $loc/dockerCall.sh .
cp $loc/createBafflesDict2.py ./Exeter_CFD_Problems/ESP/createBafflesDict2.py
cp $loc/evaluateSimulation2.py ./Exeter_CFD_Problems/ESP/evaluateSimulation2.py
cp $loc/createBafflesDict3.py ./Exeter_CFD_Problems/ESP/createBafflesDict3.py
cp $loc/evaluateSimulation3.py ./Exeter_CFD_Problems/ESP/evaluateSimulation3.py
cp $loc/createBafflesDict4.py ./Exeter_CFD_Problems/ESP/createBafflesDict4.py
cp $loc/evaluateSimulation4.py ./Exeter_CFD_Problems/ESP/evaluateSimulation4.py