#!/usr/bin/env python

import itertools

parameters = ["S", "c", "C_max", "t", "m", "n", "nP", "r_deg", "U"] #Note that the no-precedences flag is denoted by nP.

#Note that all polytime results include modes.
polytime_results = [("MRCPSP",["n"]), #Oberservation 2
                    ("MRCPSP",["r_deg", "S", "nP"]), #Corollary 3
                    ("MRCSPS",["m", "c", "C_max"]), #Theorem 4
                    ("MRCPSP", ["m", "r_deg"]), #Corollary 5
                    ("MRCPSP",["m", "nP", "C_max", "U"]), #Theorem 6
                    ("MRCSPS",["m", "c", "t", "nP"])] #Theorem 7

#Note that none of the hardness results uses modes.
hardness_results = [("RCPSP",["c", "r_deg", "t", "nP", "C_max", "U"]), #Fact 8
                    ("RCPSP",["m", "c", "t" , "S", "U"]), #Fact 9
                    ("RCPSP",["m", "c", "S", "nP", "U"]), #Fact 10
                    ("RCPSP",["m", "t", "S", "nP", "U" ]), #Observation 11
                    ("RCPSP",["c", "r_deg", "t", "S", "C_max", "U"]), #Theorem 12
                    ("RCPSP",["m", "t", "S", "C_max", "U" ]), #Theorem 13
                    ("RCPSP",["m", "t", "S", "nP", "C_max"])] #Theorem 14


###
# Hardness is implied for both MRCPSP and RCPSP with a subset of flags by our hardness reults
# if there is a hardness result with a superset of the flags in question.
# (Because none of the hardness results uses modes.)
# This is checked in the following.
###
def hardness_checker(parameter_list):
    for i in range(len(hardness_results)):
        bool = True
        for parameter in parameter_list:
            if not parameter in hardness_results[i][1]:
                bool = False
        if bool:
            return "NP-hard from", hardness_results[i]
    return "Open", "Open"

###
# Polytime solvability is implied for both MRCPSP and RCPSP with a subset of flags by our polytime results
# if there is a polytime result with a subset of the flags in question.
# (Because all of the polytime results include modes.)
# Addtionally we make use of the inference rules described in infer_poly_flags.
# This is checked in the following.
###
def infer_poly_flags(parameter_list):
    parameter_list=list(parameter_list)
    if "nP" in parameter_list and "S" in parameter_list and not "m" in parameter_list : #A simple instance
        # with no precedence constraints can be split up into m instances with one resource each.
        # Thus polynomial-time solvability is invariant under the addition of m as flag.
        parameter_list.append("m")
    if "C_max" in parameter_list and not "t" in parameter_list: #C_max is an obvious bound on t if a solution exists.
        parameter_list.append("t")
    return parameter_list

def polytime_checker(parameter_list):
    for i in range(len(polytime_results)):
        bool = True
        for j in polytime_results[i][1]:
            if not j in parameter_list:
                bool = False
        if bool:
            return "Polytime from", polytime_results[i]
    return "Open", "Open"

###
# Invocation of the hardness and polytime checker
###
def checker(parameter_list):
    hard=hardness_checker(parameter_list)
    poly=polytime_checker(infer_poly_flags(parameter_list))
    if hard[0]== "Open" and poly[0]=="Open":
        return "The complexity of this problem is open."
    if hard[0]== "Open" and poly[0]=="Open":
        return "The complexity of this problem is open."
    else:
        if hard[0]=="NP-hard from":
            return "The problem is NP-hard."
        if poly[0]=="Polytime from":
            return "The problem is polytime."

###
# Complete enumeration of all combination of flags and counting open, hard and polytime fragments.
# Open fragments are returned.
###
def enumerate_fragments():
    polytime = 0
    hard = 0
    open = 0
    open_fragments=[]
    for i in range(len(parameters)+1):
        for subset in itertools.combinations(parameters, i):
            if checker(subset)=="The complexity of this problem is open.":
                open_fragments.append([subset,"Open"])
                open +=1
            if checker(subset)=="The problem is NP-hard.":
                hard+=1
            if checker(subset)=="The problem is polytime.":
                polytime+=1
    # Counting MRCPSP and RCPSP separately necessitates multiplication by 2.
    open=open*2
    hard = hard *2
    polytime = polytime *2
    print("Number of open fragments:", open,
          "Number of NP-hard fragments:", hard,
          "Number of polytime fragments:", polytime)
    return open_fragments



print("Open fragments:", enumerate_fragments())











