function element = randpick(list)
	element = list(randi(numel(list)));
end

