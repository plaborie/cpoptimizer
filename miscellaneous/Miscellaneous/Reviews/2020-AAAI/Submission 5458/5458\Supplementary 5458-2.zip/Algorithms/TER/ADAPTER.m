classdef ADAPTER < handle
    properties
        actions
        matrix
        layers
    end
    methods
        function obj = ADAPTER(actions, layers)
            obj.actions = actions;
            obj.layers = layers;
            obj.matrix = [];
        end
        function choice = decide(obj)
            if size(obj.matrix, 2) < numel(obj.actions)
                choice = obj.actions{size(obj.matrix, 2) + 1};
                return;
            end
            empty = find(sum(obj.matrix, 2) == 0);
            if ~isempty(empty)
                choice = obj.actions{empty(1)};
                return;
            end
            temp_matrix = obj.matrix;
            mask = find(obj.matrix ~= 0);
            temp_matrix(mask) = mapminmax(temp_matrix(mask)', 0.01, 0.99);
            mask = (obj.matrix == 0);
            temp_matrix(mask) = NaN;
            M = mean(temp_matrix, 2, 'omitnan');
            empty = find(isnan(M));
            if ~isempty(empty)
                choice = obj.actions{empty(1)};
                return;
            end
            chance = softmax(5 * M); % \tau = 5
            fprintf('Adapter Matrix:\t\t\t\t\t\tChance:\n')
            disp([temp_matrix, chance]);
            %             choicenum = randsample(1: numel(obj.actions), 1, true, chance);
            %             choice = obj.actions{choicenum};
            choicenum = rand();
            S = 0;
            k = 1;
            while k <= length(chance)
                S = S + chance(k);
                if choicenum <= S
                    choice = obj.actions{k};
                    return;
                end
                k = k + 1;
            end
        end
        function update(obj, choice, value)
            actnum = ismember(obj.actions, choice);
            if size(obj.matrix, 2) == obj.layers
                obj.matrix = obj.matrix(:, 2: end);
            end
            record = zeros(numel(obj.actions), 1);
            if value == 0
                value = eps;
            end
            record(actnum) = value;
            obj.matrix = [obj.matrix, record];
        end
    end
end
