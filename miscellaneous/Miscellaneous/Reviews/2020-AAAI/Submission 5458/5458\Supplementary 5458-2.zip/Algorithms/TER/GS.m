function cratio = GS(Global)
startFEs = Global.evaluated;
GNP = 50;
FEs = 25 * Global.problem.dimension;
fitness_before = Global.bestFitness;
fprintf('GS: ');
OBJFUNC = @(X) Global.evaluate(X);
LSHADE('-objfunc', OBJFUNC, '-lb', Global.problem.lowerbound, '-ub', Global.problem.upperbound,'-HM', [], '-fbest', Global.bestFitness, '-xbest', Global.bestIndividual, '-initPop', Global.bestIndividual, '-initFit', Global.bestFitness, '-maxFEs', FEs, '-NP', GNP);
fitness_after = Global.bestFitness;
cratio = abs(fitness_before - fitness_after);
hold on;
LX = [startFEs / Global.evaluation, startFEs / Global.evaluation, Global.evaluated / Global.evaluation, Global.evaluated / Global.evaluation, 1, 1];
LY = [fitness_before, 1e-50, 1e-50, fitness_after, fitness_after, fitness_before];
fill(LX, LY, [1, 0.8, 0.8], 'EdgeColor', 'none', 'FaceAlpha', '0.2');
renderCurve(Global, false);
axis([0, 1, min(Global.trace(:, 2)), max(Global.trace(:, 2))]);
drawnow;
hold off;
fprintf('CRATIO = %.2f%%\n', 100 * cratio);
end

