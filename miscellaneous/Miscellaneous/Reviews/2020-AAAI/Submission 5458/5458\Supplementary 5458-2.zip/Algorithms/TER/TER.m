function TER(varargin)
global LS_RESTART_FLAG CC_RESTART_FLAG BICCA2_LS_STAGNANT_FLAG;
[Global, mode] = parseARGS(varargin);
LS_RESTART_FLAG = true;
CC_RESTART_FLAG = true;
BICCA2_LS_STAGNANT_FLAG = false;
actions = {'LS', 'CC', 'GS'};
Global.additionals.switchLogger = [];
adapter = ADAPTER(actions, 5);
patterns = [];
while ~Global.terminated
    startFEs = Global.evaluated;
    if strcmp(mode, 'dynamic')
        choice = adapter.decide();
    elseif strcmp(mode, 'random')
        choice = actions{ceil(numel(actions) * rand())};
    else
        choice = mode;
    end
    if strcmp(choice, 'LS')
        cratio = LS(Global);
        nchoice = 1;
    elseif strcmp(choice, 'CC')
        [cratio, patterns] = CC(Global, patterns);
        nchoice = 2;
    elseif strcmp(choice, 'GS')
        cratio = GS(Global);
        nchoice = 3;
    end
    Global.additionals.switchLogger = [Global.additionals.switchLogger; [nchoice, cratio, Global.evaluated - startFEs]];
    adapter.update(choice, cratio / (Global.evaluated - startFEs));
    fprintf('LS: %.2f%%, CC: %.2f%%, GS: %.2f%%\n', 100 * numel(find(Global.additionals.switchLogger(:, 1) == 1)) / size(Global.additionals.switchLogger, 1), 100 * numel(find(Global.additionals.switchLogger(:, 1) == 2)) / size(Global.additionals.switchLogger, 1), 100 * numel(find(Global.additionals.switchLogger(:, 1) == 3)) / size(Global.additionals.switchLogger, 1));
end
end

function [Global, mode] = parseARGS(varargin)
varargin = varargin{:};
Global = [];
mode = 'dynamic';
if numel(varargin) == 1
    Global = varargin{1};
else
    proStr = {'Global', 'mode'};
    IsString = find(cellfun(@ischar, varargin(1: end - 1)));
    [~, Loc]  = ismember(varargin(IsString), cellfun(@(S)['-', S], proStr, 'UniformOutput', false));
    for i = 1: numel(IsString)
        eval([proStr{Loc(i)}, ' = varargin{', num2str(IsString(i) + 1), '};']);
    end
end
X = initPopulation(1: Global.problem.dimension, 25, Global);
Global.evaluate(X);
X = initPopulation(1: Global.problem.dimension, 25, Global);
Global.evaluate(X);
end