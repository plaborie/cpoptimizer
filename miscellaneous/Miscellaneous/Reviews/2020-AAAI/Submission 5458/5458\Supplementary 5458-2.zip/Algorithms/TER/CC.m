function [cratio, patterns] = CC(Global, patterns)
global CC_RESTART_FLAG;
persistent maxGen NP;
startFEs = Global.evaluated;
if CC_RESTART_FLAG || isempty(patterns)
    maxGen = 250;
    NP = 15;
    clear patterns;
    CC_RESTART_FLAG = false;
end
fitness_before = Global.bestFitness;
fprintf('CC: ');
% ASYNCRONOUS OPTIMIZATION
groups = randomGroup(Global.problem.dimension, 50);
for i = 1: numel(groups)
    dims = groups{i};
    OBJFUNC = @(X) Global.evaluate(combine(X, Global.bestIndividual, dims));
    LSHADE('-objfunc', OBJFUNC, '-lb', Global.problem.lowerbound(dims), '-ub', Global.problem.upperbound(dims),'-HM', [], '-fbest', Global.bestFitness, '-xbest', Global.bestIndividual(dims), '-initPop', Global.bestIndividual(dims), '-initFit', Global.bestFitness, '-maxGen', maxGen, '-meanNP', NP);
    renderCurve(Global, false);
    axis([0, 1, min(Global.trace(:, 2)), max(Global.trace(:, 2))]);
    drawnow;
end
fitness_after = Global.bestFitness;
cratio = abs(fitness_before - fitness_after);
hold on;
LX = [startFEs / Global.evaluation, startFEs / Global.evaluation, Global.evaluated / Global.evaluation, Global.evaluated / Global.evaluation, 1, 1];
LY = [fitness_before, 1e-50, 1e-50, fitness_after, fitness_after, fitness_before];
fill(LX, LY, [0.8, 0.8, 1], 'EdgeColor', 'none', 'FaceAlpha', '0.2');
axis([0, 1, min(Global.trace(:, 2)), max(Global.trace(:, 2))]);
drawnow;
hold off;
fprintf('CRATIO = %.3f%%\n', 100 * cratio);
patterns = [];
end