clear;
clf;
cla;
samples = 1001;
mainFolders = {'Results\LSO08\D1000\BICCA2', 'Results\LSO08\D2500\BICCA2', 'Results\LSO08\D5000\BICCA2', 'Results\LSO08\D10000\BICCA2'};
problem = 'LSO08F6';
algorithms = {'1000D', '2500D', '5000D', '10000D'};
% Interface: [spercentage, sdata] = collectData(samples, fileFolder, algorithm, problem, dimension, evaluation)
gathereddata.percentage = [];
gathereddata.data = [];
gathereddata.problem = [];
gathereddata.algorithm = [];
gathereddata = repmat(gathereddata, numel(algorithms), 1);
for i = 1: numel(algorithms)
    gathereddata(i).algorithm = algorithms{i};
    gathereddata(i).problem = problem;
    if strcmp(problem, 'LSO13F13')
        dimension = 905;
    else
        dimension = 1000;
    end
    if i == 1
        algname = 'BICCA2';
    else
        algname = 'BICCA2';
    end
    [gathereddata(i).percentage, gathereddata(i).data] = collectData(samples, fullfile(mainFolders{i}), algname, problem, dimension, 56);
end
Curves = bandParser(gathereddata);
axis square;
axis([0, 1, 0, inf]);
set(gca, 'yscale', 'log');
for i = 1: numel(algorithms)
    name = replace(algorithms{i}, '_', '\_');
    % name = replace(name, 'BICCA2', 'IPAS');
    name = replace(name, 'DECCD', 'DECC-D');
    name = replace(name, 'DECCG', 'DECC-G');
    name = replace(name, 'DECCDML', 'DECC-DML');
    name = replace(name, 'DECCDG', 'DECC-DG');
    name = replace(name, 'DECCDG', 'DECC-DG2');
    name = replace(name, 'CCCMAES', 'CC-CMA-ES');
    Legends{i} = name;
end
L = legend([Curves{:}]', Legends{:});
set(L, 'FontName', 'Book Antiqua', 'FontSize', 12);





function Curves = bandParser(gathereddata)
Curves = {};
LineColors = linspecer(numel(gathereddata) - 1);
for i = 1: numel(gathereddata)
    MEAN = mean(gathereddata(i).data, 'omitnan');
    VARIANCE = [min(gathereddata(i).data, [], 1, 'omitnan'); max(gathereddata(i).data, [], 1, 'omitnan')];
    CONFIDENCE = [NaN(size(gathereddata(i).percentage)); NaN(size(gathereddata(i).percentage))];
    for j = 1: size(gathereddata(i).data, 2)
        D = gathereddata(i).data(:, j);
        if sum(D) == 0
            CONFIDENCE(:, j) = [0; 0];
            continue;
        end
        D(D == inf) = [];
        D(D == 0) = eps;
        [phat, pci] = mle(D, 'dist', 'logn');
        CONFIDENCE(:, j) = exp(pci(:, 1)) - exp(phat(1)) + MEAN(j);
    end
    PERCENTAGE = gathereddata(i).percentage;
    if strcmp(gathereddata(i).algorithm, '1000D')
        [Curves{i}, ~, ~] = bandDrawer(PERCENTAGE, MEAN, CONFIDENCE, VARIANCE, [0, 0, 1]);
    else
        [Curves{i}, ~, ~] = bandDrawer(PERCENTAGE, MEAN, CONFIDENCE, VARIANCE, LineColors(i - 1, :));
    end
    hold on;
end
drawnow;
end
function [Curve, ConfidenceArea, VarianceArea] = bandDrawer(varargin)
set(gcf, 'Renderer', 'Painter');
if nargin == 4 % PERCENTAGE, MEAN, CONFIDENCE, VARIANCE
    PERCENTAGE = varargin{1};
    MEAN = varargin{2};
    CONFIDENCE = varargin{3};
    VARIANCE = varargin{4};
    LineWidth = 1;
    Curve = plot(PERCENTAGE, MEAN, 'LineWidth', LineWidth);
elseif nargin == 5 % PERCENTAGE, MEAN, CONFIDENCE, VARIANCE, COLOR
    PERCENTAGE = varargin{1};
    MEAN = varargin{2};
    CONFIDENCE = varargin{3};
    VARIANCE = varargin{4};
    COLOR = varargin{5};
    LineWidth = 2;
    Curve = plot(PERCENTAGE, MEAN, 'LineWidth', LineWidth, 'COLOR', COLOR);
end
COLOR = Curve.Color;
delete(Curve);
ConfidenceArea = fill([PERCENTAGE, flip(PERCENTAGE)], [CONFIDENCE(1, :), flip(CONFIDENCE(2, :))], COLOR, 'EdgeColor', 'none', 'FaceAlpha', '0.4');
hold on;
% VarianceArea = fill([PERCENTAGE, flip(PERCENTAGE)], [VARIANCE(1, :), flip(VARIANCE(2, :))], COLOR, 'EdgeColor', 'none', 'FaceAlpha', '0.2');
VarianceArea = [];
Curve = plot(PERCENTAGE, MEAN, '-', 'LineWidth', LineWidth, 'COLOR', COLOR);
drawnow;
end

function [spercentage, sdata] = collectData(samples, fileFolder, algorithm, problem, dimension, evaluation)
dirOutput = dir(fullfile(fileFolder, '*'));
filenames = {dirOutput.name}';
reduce_index = [];
for i = 1: numel(filenames)
    expr1 = sprintf('%s_%s_', algorithm, problem);
    expr2 = sprintf('%s.mat', problem);
    if isempty(strfind(filenames{i}, expr1)) && isempty(strfind(filenames{i}, expr2))
        reduce_index = [reduce_index, i];
    end
end
filenames(reduce_index) = [];
sdata = NaN(numel(filenames), samples);
spercentage = linspace(0, 1, samples);
for i = 1: numel(filenames)
	load(fullfile(fileFolder, filenames{i}));
    sdata(i, :) = curveSampler(spercentage, G.trace(:, 1), G.trace(:, 2));
    clear G;
end
end